# How to install

Navigate to chrome://extensions/ and select "Load unpacked" and choose this directory.
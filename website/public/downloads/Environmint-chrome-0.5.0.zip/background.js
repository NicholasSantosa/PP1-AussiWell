chrome.runtime.onMessageExternal.addListener((message) => {
    console.log(message);
});